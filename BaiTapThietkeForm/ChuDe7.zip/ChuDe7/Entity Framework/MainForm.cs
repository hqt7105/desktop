﻿using Entity_Framework.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Entity_Framework
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            ShowCategories();
            if (tvwCategory.Nodes.Count > 0)
                ShowFoodsForNode(tvwCategory.Nodes[0]);


        }

        private void btnReloadCategory_Click(object sender, EventArgs e)
        {
            ShowCategories();
     
        }

        private List<Category> GetCategories()
        {
            var dbContext = new RestaurantContext();
            
                //Lấy ds thức ăn, sắp xếp theo tên
                return dbContext.Categories.OrderBy(x => x.Name).ToList();
            
        }

        private void ShowCategories()
        {
            //Xóa tất cả các nút hiện có trên cây
            tvwCategory.Nodes.Clear();


            //Tạo ds 
            //Tên các loại được hiện trên nút mức 2
            var cateMap = new Dictionary<CategoryType, string>()
            {
                [CategoryType.Food] = "Đồ ăn",
                [CategoryType.Drink] = "Thức uống"
            };


            //Tạo nút trên cây
            var rootNode = tvwCategory.Nodes.Add("Tất cả");


            //Lấy danh sách nhóm thức ăn, thức uống
            var categories = GetCategories();

            foreach (var cateType in cateMap)
            {
                //Tạo nút tương đương nhóm món ăn
                var childNode = rootNode.Nodes.Add(cateType.Key.ToString(), cateType.Value);
                childNode.Tag = cateType.Key;

                //Duyệt qua các món ăn

                foreach (var category in categories)
                {
                    //Nếu nhóm đang xét khác loại thì bỏ qua
                    if (category.Type != cateType.Key) continue;

                    var grantChildNode = childNode.Nodes.Add(category.Id.ToString(), category.Name);
                    grantChildNode.Tag = category;
                }
            }
            //Mở rộng các nhánh của cây để thấy tất cả các nhóm thức ăn
            tvwCategory.ExpandAll();

            //Đánh dấu nút gốc được chọn
            tvwCategory.SelectedNode = rootNode;

        }

        private List<FoodModels> GetFoodByCategory(int? categoryID)
        {
            var dbContext = new RestaurantContext();

            //tạo truy vấn lấy danh sách món ăn
            var foods = dbContext.Foods.AsQueryable();

            if (categoryID != null && categoryID > 0)
            {
                foods = foods.Where(x => x.FoodCategoryId == categoryID);
            }
            return foods
                .OrderBy(x => x.Name)
                .Select(x => new FoodModels()
                {
                    Id = x.Id,
                    Name = x.Name,
                    Unit = x.Unit,
                    Price = x.Price,
                    Notes = x.Notes,
                    CategoryName = x.Category.Name

                })
                .ToList();
        }
        private List<FoodModels> GetFoodByCategoryType(CategoryType cateType)
        {
            var dbContext = new RestaurantContext();
            return dbContext.Foods
                .Where(x => x.Category.Type == cateType)
                .OrderBy(x => x.Name)
                .Select(x => new FoodModels()
                {
                    Id = x.Id,
                    Name = x.Name,
                    Unit = x.Unit,
                    Price = x.Price,
                    Notes = x.Notes,
                    CategoryName = x.Category.Name
                })
                .ToList();
        }


        private void ShowFoodsForNode(TreeNode node)
        {
            lvwFood.Items.Clear();

            if (node == null) return;

            List<FoodModels> foods = null;
            if(node.Level == 1)
            {
                var categoryType = (CategoryType)node.Tag;
                foods = GetFoodByCategoryType(categoryType);
            }
            else
            {
                var category = node.Tag as Category;    
                foods = GetFoodByCategory(category?.Id);
            }
            ShowFoodsOnListView(foods);
                
        }

        private void ShowFoodsOnListView(List<FoodModels> foods)
        {
            foreach(var foodItem in foods)
            {
                var item = lvwFood.Items.Add(foodItem.Id.ToString());

                item.SubItems.Add(foodItem.Name);
                item.SubItems.Add(foodItem.Unit);
                item.SubItems.Add(foodItem.Price.ToString("##,###"));
                item.SubItems.Add(foodItem.CategoryName);
                item.SubItems.Add(foodItem.Notes);
            }        
        }

        private void tvwCategory_AfterSelect(object sender, TreeViewEventArgs e)
        {
            ShowFoodsForNode(e.Node);
        }


        private void btnAddCategory_Click(object sender, EventArgs e)
        {
            var dialog = new UpdateCategoryForm();
            if (dialog.ShowDialog(this) == DialogResult.OK)
                ShowCategories();
        }


        private void tvwCategory_NodeMouseDoubleClick(object sender, TreeNodeMouseClickEventArgs e)
        {
            if (e.Node == null || e.Node.Level < 2 || e.Node.Tag == null) return;
            var category = e.Node.Tag as Category;
            var dialog = new UpdateCategoryForm(category?.Id);
            if(dialog.ShowDialog(this) == DialogResult.OK)
                ShowCategories();
        }

        private void btnReloadFood_Click(object sender, EventArgs e)
        {
            ShowFoodsForNode(tvwCategory.SelectedNode);
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if(lvwFood.SelectedItems.Count == 0) return;

            var dbContext = new RestaurantContext();
            var selectedFoodId = int.Parse(lvwFood.SelectedItems[0].Text);
            var selectedFood = dbContext.Foods.Find(selectedFoodId);

            if(selectedFood!=null)
            {
                dbContext.Foods.Remove(selectedFood);
                dbContext.SaveChanges();

                lvwFood.Items.Remove(lvwFood.SelectedItems[0]);
            }    
        }

        private void btnAddFood_Click(object sender, EventArgs e)
        {
            var dialog = new UpdateFoodForm();
            if(dialog.ShowDialog(this)==DialogResult.OK)
            {
                ShowFoodsForNode(tvwCategory.SelectedNode);
            }    
        }

        private void lvwFood_DoubleClick(object sender, EventArgs e)
        {
            if (lvwFood.SelectedItems.Count == 0) return;
            var foodId = int.Parse(lvwFood.SelectedItems[0].Text);
            var dialog = new UpdateFoodForm(foodId);
            if (dialog.ShowDialog(this) == DialogResult.OK)
            {
                ShowFoodsForNode(tvwCategory.SelectedNode);
            }

        }
    }
}

