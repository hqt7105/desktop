﻿-- =============================================
-- DATABASE: RestaurantManagement
-- =============================================
CREATE DATABASE RestaurantManagements;
GO
USE RestaurantManagements;
GO

-- =============================================
-- Bảng Restaurant
-- =============================================
CREATE TABLE Restaurant (
    ID INT IDENTITY(1,1) PRIMARY KEY,
    Name NVARCHAR(1000) NOT NULL DEFAULT N'Chưa đặt tên',
    Address NVARCHAR(3000) DEFAULT N'Chưa có địa chỉ',
    Phone NVARCHAR(100) DEFAULT N'02633…',
    Website NVARCHAR(1000) NULL
);
GO

-- =============================================
-- Bảng Hall
-- =============================================
CREATE TABLE Hall (
    ID INT IDENTITY(1,1) PRIMARY KEY,
    Name NVARCHAR(1000) DEFAULT N'Chưa đặt tên',
    RestaurantID INT NOT NULL,
    FOREIGN KEY (RestaurantID) REFERENCES Restaurant(ID)
);
GO

-- =============================================
-- Bảng Table
-- =============================================
CREATE TABLE [Table] (
    ID INT IDENTITY(1,1) PRIMARY KEY,
    TableCode NVARCHAR(200) NOT NULL,
    Name NVARCHAR(1000) DEFAULT N'Không đặt tên',
    Status INT DEFAULT 0,  -- 0: chưa đặt; 1: đã đặt; 2: có khách
    Seats INT NULL,
    HallID INT NOT NULL,
    FOREIGN KEY (HallID) REFERENCES Hall(ID)
);
GO

-- =============================================
-- Bảng Category
-- =============================================
CREATE TABLE Category (
    ID INT IDENTITY(1,1) PRIMARY KEY,
    Name NVARCHAR(1000) DEFAULT N'Chưa đặt tên',
    Type INT NOT NULL -- 1: thức ăn; 0: đồ uống
);
GO

-- =============================================
-- Bảng Food
-- =============================================
CREATE TABLE Food (
    ID INT IDENTITY(1,1) PRIMARY KEY,
    Name NVARCHAR(1000) DEFAULT N'Chưa đặt tên',
	Unit nvarchar(100),
    FoodCategoryID INT NOT NULL,
    Price FLOAT DEFAULT 0,
    Notes NVARCHAR(3000) NULL,
    FOREIGN KEY (FoodCategoryID) REFERENCES Category(ID)
);
GO

-- =============================================
-- Bảng Invoice
-- =============================================
CREATE TABLE Invoice (
    ID INT IDENTITY(1,1) PRIMARY KEY,
    Name NVARCHAR(1000) DEFAULT N'Hóa đơn chưa thanh toán',
    TableID INT NOT NULL,
    Total INT DEFAULT 0,
    Discount FLOAT DEFAULT 0,
    Tax FLOAT DEFAULT 0,
    Status INT DEFAULT 0, -- 0: chưa thanh toán, 1: đã thanh toán
    AccountID NVARCHAR(100) NOT NULL,
    CheckoutDate SMALLDATETIME DEFAULT GETDATE(),
    FOREIGN KEY (TableID) REFERENCES [Table](ID)
);
GO

-- =============================================
-- Bảng InvoiceDetails
-- =============================================
CREATE TABLE InvoiceDetails (
    ID INT IDENTITY(1,1) PRIMARY KEY,
    InvoiceID INT NOT NULL,
    FoodID INT NOT NULL,
    Quantity INT DEFAULT 1,
    Price FLOAT DEFAULT 0,
    FOREIGN KEY (InvoiceID) REFERENCES Invoice(ID),
    FOREIGN KEY (FoodID) REFERENCES Food(ID)
);
GO

-- =============================================
-- Bảng Account
-- =============================================
CREATE TABLE Account (
    AccountName NVARCHAR(100) PRIMARY KEY,
    Password NVARCHAR(200) NOT NULL,
    FullName NVARCHAR(1000) NULL,
    Email NVARCHAR(1000) NULL,
    Phone NVARCHAR(200) NULL,
    DateCreated SMALLDATETIME DEFAULT GETDATE()
);
GO

-- =============================================
-- Bảng Role
-- =============================================
CREATE TABLE Role (
    ID INT IDENTITY(1,1) PRIMARY KEY,
    RoleName NVARCHAR(1000) NOT NULL,
    Path NVARCHAR(3000) NULL,
    Notes NVARCHAR(3000) NULL
);
GO

-- =============================================
-- Bảng RoleAccount
-- =============================================
CREATE TABLE RoleAccount (
    AccountName NVARCHAR(100) NOT NULL,
    RoleID INT NOT NULL,
    Actived BIT DEFAULT 1,
    Notes NVARCHAR(3000) NULL,
    PRIMARY KEY (AccountName, RoleID),
    FOREIGN KEY (AccountName) REFERENCES Account(AccountName),
    FOREIGN KEY (RoleID) REFERENCES Role(ID)
);
GO

-- =============================================
-- DỮ LIỆU MẪU
-- =============================================

-- Restaurant
INSERT INTO Restaurant (Name, Address, Phone, Website)
VALUES 
(N'Nhà hàng Biển Xanh', N'123 Nguyễn Huệ, TP. HCM', N'0901234567', N'www.bienxanh.vn'),
(N'Nhà hàng Hoa Mai', N'45 Lê Lợi, Đà Nẵng', N'0907654321', N'www.hoamai.com');

-- Hall
INSERT INTO Hall (Name, RestaurantID)
VALUES 
(N'Sảnh 1', 1),
(N'Sảnh 2', 1),
(N'Sảnh VIP', 2);

-- Table
INSERT INTO [Table] (TableCode, Name, Status, Seats, HallID)
VALUES
(N'B1.01', N'Bàn VIP 1', 0, 10, 3),
(N'B1.02', N'Bàn Khách 2', 1, 6, 1),
(N'B2.01', N'Bàn 1 Sảnh 2', 2, 8, 2);

-- FoodCategory
INSERT INTO Category (Name, Type)
VALUES 
(N'Món chính', 1),
(N'Nước uống', 0);

-- Food
INSERT INTO Food (Name, Unit,FoodCategoryID, Price, Notes)
VALUES
(N'Cơm chiên hải sản',N'Đĩa', 1, 50000, N'Món phổ biến'),
(N'Bò lúc lắc',N'Đĩa', 1, 75000, N'Món đặc biệt'),
(N'Nước cam',N'Ly', 2, 25000, N'Tươi mát'),
(N'Coca-Cola',N'Lon', 2, 20000, N'Đồ uống phổ thông');

-- Account
INSERT INTO Account (AccountName, Password, FullName, Email, Phone)
VALUES
(N'admin', N'123', N'Nguyễn Văn Admin', N'admin@res.com', N'0900000001'),
(N'manager', N'123', N'Trần Thị Quản Lý', N'manager@res.com', N'0900000002'),
(N'accountant', N'123', N'Lê Văn Kế Toán', N'accountant@res.com', N'0900000003'),
(N'staff', N'123', N'Phạm Thị Nhân Viên', N'staff@res.com', N'0900000004');

-- Role
INSERT INTO Role (RoleName, Path, Notes)
VALUES 
(N'Admin', NULL, N'Toàn quyền hệ thống'),
(N'Quản lý', NULL, N'Quản lý nhân viên, thực đơn, doanh thu'),
(N'Kế toán', NULL, N'Theo dõi hóa đơn, thống kê'),
(N'Nhân viên', NULL, N'Nhân viên phục vụ, nhập hóa đơn');

-- RoleAccount
INSERT INTO RoleAccount (AccountName, RoleID, Actived, Notes)
VALUES
(N'admin', 1, 1, N'Toàn quyền hệ thống'),
(N'manager', 2, 1, N'Quản lý chính nhà hàng'),
(N'accountant', 3, 1, N'Theo dõi doanh thu'),
(N'staff', 4, 1, N'Nhân viên phục vụ');

-- Invoice
INSERT INTO Invoice (Name, TableID, Total, Discount, Tax, Status, AccountID)
VALUES
(N'Hóa đơn bàn VIP 1', 1, 150000, 0, 10, 1, N'admin'),
(N'Hóa đơn bàn 2 sảnh 1', 2, 75000, 5, 10, 0, N'nhanvien1');

-- InvoiceDetails
INSERT INTO InvoiceDetails (InvoiceID, FoodID, Quantity, Price)
VALUES
(1, 1, 2, 50000),
(1, 3, 1, 25000),
(2, 2, 1, 75000);
GO

-- Xóa các bảng con trước, rồi đến bảng cha
--DROP TABLE IF EXISTS RoleAccount;
--DROP TABLE IF EXISTS InvoiceDetails;
--DROP TABLE IF EXISTS Invoice;
--DROP TABLE IF EXISTS Food;
--DROP TABLE IF EXISTS Category;
--DROP TABLE IF EXISTS [Table];
--DROP TABLE IF EXISTS Hall;
--DROP TABLE IF EXISTS Restaurant;
--DROP TABLE IF EXISTS Account;
--DROP TABLE IF EXISTS Role;
--GO



-- Thu tuc
Create proc [dbo].[Category_GetAll]
AS
Select * From Category
Go

Create proc [dbo].[Food_GetAll]
As
Select * from Food
Go

Create proc [dbo].[Table_GetAll]
As
Select * from [Table]
Go

Create Proc dbo.Category_InsertUpdateDelete
	@ID int output,
	@Name nvarchar(200),
	@Type int,
	@Action int
As 
	IF @Action = 0
		Begin
			Insert Into [Category] ([Name],[Type])
			Values(@Name,@Type)
			Set @ID=@@IDENTITY
		End
	Else if @Action=1
		Begin
			Update [Category] Set [Name] = @Name, [Type]=@Type
			Where [ID]=@ID
		End
	Else if @Action = 2
		Begin
			Delete from Category
			Where ID =@ID
		End
GO

-- Thủ tục thêm, xóa, sửa bảng Food
Create PROCEDURE [dbo]. [Food_InsertUpdateDelete]
	@ID int output, -- Biến ID tự tăng, khi thêm xong phải lấy ra
	@Name nvarchar(1000),
	@Unit nvarchar(100),
	@FoodCategoryID int,
	@Price int,
	@Notes nvarchar(3000),
	@Action int -- Bien cho biết thêm, xoa, hay sửa

	As
	IF @Action = 0 -- Nếu Action = 0, thêm dữ liệu
		BEGIN
			INSERT INTO [Food]
			([Name], [Unit], [FoodCategoryID], [Price], [Notes])
			VALUES (@Name, @Unit,@FoodCategoryID,@Price,@Notes)
			SET @ID = @@identity -- Thiết lập ID tự tăng
		End
	ELSE IF @Action = 1 -- Neu Action = 1, cập nhật dữ liệu
		BEGIN
			UPDATE [Food]
			SET [Name] = @Name, [Unit]=@Unit, [FoodCategoryID]=@FoodCategoryID,
			[Price]=@Price, [Notes]=@Notes
			WHERE [ID] = @ID
		End
	ELSE IF @Action = 2 -- Nếu Action = 2, xoa dữ liệu
		BEGIN
			DELETE FROM [Food] WHERE [ID] = @ID
		END
Go

CREATE PROC dbo.Restaurant_InsertUpdateDelete
    @ID INT OUTPUT,
    @Name NVARCHAR(1000),
    @Address NVARCHAR(3000),
    @Phone NVARCHAR(100),
    @Website NVARCHAR(1000),
    @Action INT
AS
BEGIN
    IF @Action = 0
    BEGIN
        INSERT INTO Restaurant ([Name],[Address],[Phone],[Website])
        VALUES (@Name,@Address,@Phone,@Website)
        SET @ID = @@IDENTITY
    END
    ELSE IF @Action = 1
    BEGIN
        UPDATE Restaurant
        SET [Name] = @Name, [Address] = @Address, [Phone] = @Phone, [Website] = @Website
        WHERE [ID] = @ID
    END
    ELSE IF @Action = 2
    BEGIN
        DELETE FROM Restaurant WHERE [ID] = @ID
    END
END
GO


CREATE PROC dbo.Hall_InsertUpdateDelete
    @ID INT OUTPUT,
    @Name NVARCHAR(1000),
    @RestaurantID INT,
    @Action INT
AS
BEGIN
    IF @Action = 0
    BEGIN
        INSERT INTO Hall ([Name], [RestaurantID])
        VALUES (@Name, @RestaurantID)
        SET @ID = SCOPE_IDENTITY()
    END
    ELSE IF @Action = 1
    BEGIN
        UPDATE Hall
        SET [Name] = @Name,
            [RestaurantID] = @RestaurantID
        WHERE [ID] = @ID
    END
    ELSE IF @Action = 2
    BEGIN
        DELETE FROM Hall
        WHERE [ID] = @ID
    END
END
GO

CREATE PROC dbo.Table_InsertUpdateDelete
    @ID INT OUTPUT,
    @TableCode NVARCHAR(200),
    @Name NVARCHAR(1000),
    @Status INT,
    @Seats INT,
    @HallID INT,
    @Action INT
AS
BEGIN
    IF @Action = 0
    BEGIN
        INSERT INTO [Table] (TableCode, Name, Status, Seats, HallID)
        VALUES (@TableCode, @Name, @Status, @Seats, @HallID)
        SET @ID = @@IDENTITY
    END
    ELSE IF @Action = 1
    BEGIN
        UPDATE [Table]
        SET TableCode = @TableCode,
            Name = @Name,
            Status = @Status,
            Seats = @Seats,
            HallID = @HallID
        WHERE ID = @ID
    END
    ELSE IF @Action = 2
    BEGIN
        DELETE FROM [Table] WHERE ID = @ID
    END
END
GO

IF OBJECT_ID('Invoice_GetAll', 'P') IS NOT NULL DROP PROC Invoice_GetAll;
GO
CREATE PROCEDURE Invoice_GetAll
AS
BEGIN
    SET NOCOUNT ON;
    SELECT i.*, t.Name AS TableName, a.FullName AS AccountName
    FROM Invoice i
    LEFT JOIN [Table] t ON i.TableID = t.ID
    LEFT JOIN Account a ON i.AccountID = a.AccountName;
END;
GO

IF OBJECT_ID('Invoice_InsertUpdateDelete', 'P') IS NOT NULL DROP PROC Invoice_InsertUpdateDelete;
GO
CREATE PROCEDURE Invoice_InsertUpdateDelete
    @ID INT,
    @Name NVARCHAR(500),
    @TableID INT,
    @Total FLOAT,
    @Discount FLOAT,
    @Tax FLOAT,
    @Status INT,
    @AccountID NVARCHAR(100),
    @CheckoutDate SMALLDATETIME,
    @Action INT  -- 0: Insert, 1: Update, 2: Delete
AS
BEGIN
    SET NOCOUNT ON;
    IF @Action = 0
    BEGIN
        INSERT INTO Invoice (Name, TableID, Total, Discount, Tax, Status, AccountID, CheckoutDate)
        VALUES (@Name, @TableID, @Total, @Discount, @Tax, @Status, @AccountID, @CheckoutDate);

        SELECT SCOPE_IDENTITY() AS NewID;
    END
    ELSE IF @Action = 1
    BEGIN
        UPDATE Invoice
        SET Name=@Name, TableID=@TableID, Total=@Total, Discount=@Discount, Tax=@Tax,
            Status=@Status, AccountID=@AccountID, CheckoutDate=@CheckoutDate
        WHERE ID=@ID;
    END
    ELSE IF @Action = 2
    BEGIN
        DELETE FROM Invoice WHERE ID=@ID;
    END
END;
GO

IF OBJECT_ID('InvoiceDetail_GetByInvoiceID','P') IS NOT NULL DROP PROC InvoiceDetail_GetByInvoiceID;
GO
CREATE PROCEDURE InvoiceDetail_GetByInvoiceID
    @InvoiceID INT
AS
BEGIN
    SET NOCOUNT ON;
    SELECT d.*, f.Name AS FoodName, f.Price AS FoodPrice
    FROM InvoiceDetail d
    LEFT JOIN Food f ON d.FoodID = f.ID
    WHERE d.InvoiceID = @InvoiceID;
END;
GO

IF OBJECT_ID('InvoiceDetail_InsertUpdateDelete','P') IS NOT NULL DROP PROC InvoiceDetail_InsertUpdateDelete;
GO
CREATE PROCEDURE InvoiceDetail_InsertUpdateDelete
    @ID INT,
    @InvoiceID INT,
    @FoodID INT,
    @Quantity INT,
    @Price FLOAT,
    @Action INT -- 0: Insert, 1: Update, 2: Delete
AS
BEGIN
    SET NOCOUNT ON;
    IF @Action = 0
    BEGIN
        INSERT INTO InvoiceDetail(InvoiceID, FoodID, Quantity, Price)
        VALUES(@InvoiceID, @FoodID, @Quantity, @Price);
    END
    ELSE IF @Action = 1
    BEGIN
        UPDATE InvoiceDetail
        SET FoodID=@FoodID, Quantity=@Quantity, Price=@Price
        WHERE ID=@ID;
    END
    ELSE IF @Action = 2
    BEGIN
        DELETE FROM InvoiceDetail WHERE ID=@ID;
    END
END;
GO

IF OBJECT_ID('InvoiceDetail_DeleteByInvoiceID','P') IS NOT NULL DROP PROC InvoiceDetail_DeleteByInvoiceID;
GO
CREATE PROCEDURE InvoiceDetail_DeleteByInvoiceID
    @InvoiceID INT
AS
BEGIN
    SET NOCOUNT ON;
    DELETE FROM InvoiceDetail WHERE InvoiceID = @InvoiceID;
END;
GO

IF OBJECT_ID('Invoice_CreateForTable','P') IS NOT NULL DROP PROC Invoice_CreateForTable;
GO
CREATE PROCEDURE Invoice_CreateForTable
    @TableID INT,
    @AccountID NVARCHAR(100),
    @NewInvoiceID INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    BEGIN TRAN
    BEGIN TRY
        INSERT INTO Invoice(Name, TableID, Total, Discount, Tax, Status, AccountID, CheckoutDate)
        VALUES(CONCAT(N'HĐ_', @TableID,'_',REPLACE(CONVERT(VARCHAR(23), GETDATE(), 121),':','-')), @TableID, 0, 0, 0, 0, @AccountID, GETDATE());
        SET @NewInvoiceID = SCOPE_IDENTITY();

        UPDATE TableFood SET Status = N'Có khách' WHERE ID = @TableID;

        COMMIT TRAN;
    END TRY
    BEGIN CATCH
        ROLLBACK TRAN;
        THROW;
    END CATCH
END;
GO

IF OBJECT_ID('Invoice_Checkout','P') IS NOT NULL DROP PROC Invoice_Checkout;
GO
CREATE PROCEDURE Invoice_Checkout
    @InvoiceID INT,
    @Discount FLOAT,
    @Tax FLOAT,
    @PaidAmount FLOAT,
    @AccountID NVARCHAR(100)
AS
BEGIN
    SET NOCOUNT ON;
    BEGIN TRAN
    BEGIN TRY
        DECLARE @Total FLOAT;
        SELECT @Total = SUM(Quantity * Price) FROM InvoiceDetail WHERE InvoiceID = @InvoiceID;

        IF @Total IS NULL SET @Total = 0;

        SET @Total = @Total - ISNULL(@Discount,0) + ISNULL(@Tax,0);

        UPDATE Invoice
        SET Total = @Total, Discount = ISNULL(@Discount,0), Tax = ISNULL(@Tax,0), Status = 1, AccountID = @AccountID, CheckoutDate = GETDATE()
        WHERE ID = @InvoiceID;

        -- set table status empty (assume one invoice per table active)
        DECLARE @TableID INT;
        SELECT @TableID = TableID FROM Invoice WHERE ID = @InvoiceID;
        IF @TableID IS NOT NULL
            UPDATE TableFood SET Status = N'Trống' WHERE ID = @TableID;

        COMMIT TRAN;
    END TRY
    BEGIN CATCH
        ROLLBACK TRAN;
        THROW;
    END CATCH
END;
GO


CREATE PROC dbo.InvoiceDetail_GetByInvoiceID
    @InvoiceID INT
AS
BEGIN
    SELECT 
        BD.ID,
        BD.InvoiceID,
        BD.FoodID,
        F.Name AS FoodName,
        BD.Quantity,
        BD.Price
    FROM InvoiceDetails BD
    INNER JOIN Food F ON BD.FoodID = F.ID
    WHERE BD.InvoiceID = @InvoiceID
END
GO

IF EXISTS (SELECT * FROM sys.objects WHERE type = 'P' AND name = 'InvoiceDetail_GetByInvoiceID')
    DROP PROCEDURE InvoiceDetail_GetByInvoiceID;
GO

CREATE PROCEDURE InvoiceDetail_GetByInvoiceID
    @InvoiceID INT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT 
        d.ID,
        d.InvoiceID,
        d.FoodID,
        f.Name AS FoodName,
        d.Quantity,
        d.Price
    FROM InvoiceDetails d
    INNER JOIN Food f ON d.FoodID = f.ID
    WHERE d.InvoiceID = @InvoiceID;
END;
GO

IF EXISTS (SELECT * FROM sys.objects WHERE type = 'P' AND name = 'Account_GetAll')
    DROP PROCEDURE Account_GetAll;
GO
CREATE PROCEDURE Account_GetAll
AS
BEGIN
    SELECT * FROM Account;
END;
GO

IF EXISTS (SELECT * FROM sys.objects WHERE type = 'P' AND name = 'Account_InsertUpdateDelete')
    DROP PROCEDURE Account_InsertUpdateDelete;
GO
CREATE PROCEDURE Account_InsertUpdateDelete
    @AccountName NVARCHAR(100),
    @Password NVARCHAR(200),
    @FullName NVARCHAR(1000),
    @Email NVARCHAR(1000),
    @Phone NVARCHAR(200),
    @Action INT
AS
BEGIN
    IF (@Action = 0) -- INSERT
    BEGIN
        INSERT INTO Account (AccountName, Password, FullName, Email, Phone)
        VALUES (@AccountName, @Password, @FullName, @Email, @Phone);
    END
    ELSE IF (@Action = 1) -- UPDATE
    BEGIN
        UPDATE Account
        SET Password = @Password,
            FullName = @FullName,
            Email = @Email,
            Phone = @Phone
        WHERE AccountName = @AccountName;
    END
    ELSE IF (@Action = 2) -- DELETE
    BEGIN
        DELETE FROM Account WHERE AccountName = @AccountName;
    END
END;
GO

IF EXISTS (SELECT * FROM sys.objects WHERE type = 'P' AND name = 'Role_GetAll')
    DROP PROCEDURE Role_GetAll;
GO
CREATE PROCEDURE Role_GetAll
AS
BEGIN
    SELECT * FROM Role;
END;
GO

IF EXISTS (SELECT * FROM sys.objects WHERE type = 'P' AND name = 'Role_InsertUpdateDelete')
    DROP PROCEDURE Role_InsertUpdateDelete;
GO
CREATE PROCEDURE Role_InsertUpdateDelete
    @ID INT,
    @RoleName NVARCHAR(1000),
    @Path NVARCHAR(3000),
    @Notes NVARCHAR(3000),
    @Action INT
AS
BEGIN
    IF (@Action = 0) -- INSERT
    BEGIN
        INSERT INTO Role (RoleName, Path, Notes)
        VALUES (@RoleName, @Path, @Notes);
    END
    ELSE IF (@Action = 1) -- UPDATE
    BEGIN
        UPDATE Role
        SET RoleName = @RoleName,
            Path = @Path,
            Notes = @Notes
        WHERE ID = @ID;
    END
    ELSE IF (@Action = 2) -- DELETE
    BEGIN
        DELETE FROM Role WHERE ID = @ID;
    END
END;
GO

IF EXISTS (SELECT * FROM sys.objects WHERE type = 'P' AND name = 'RoleAccount_GetAll')
    DROP PROCEDURE RoleAccount_GetAll;
GO
CREATE PROCEDURE RoleAccount_GetAll
AS
BEGIN
    SELECT 
        ra.AccountName,
        ra.RoleID,
        a.FullName,
        r.RoleName,
        ra.Actived,
        ra.Notes
    FROM RoleAccount ra
    INNER JOIN Account a ON ra.AccountName = a.AccountName
    INNER JOIN Role r ON ra.RoleID = r.ID;
END;
GO

IF EXISTS (SELECT * FROM sys.objects WHERE type = 'P' AND name = 'RoleAccount_InsertUpdateDelete')
    DROP PROCEDURE RoleAccount_InsertUpdateDelete;
GO
CREATE PROCEDURE RoleAccount_InsertUpdateDelete
    @AccountName NVARCHAR(100),
    @RoleID INT,
    @Actived BIT,
    @Notes NVARCHAR(3000),
    @Action INT
AS
BEGIN
    IF (@Action = 0) -- INSERT
    BEGIN
        INSERT INTO RoleAccount (AccountName, RoleID, Actived, Notes)
        VALUES (@AccountName, @RoleID, @Actived, @Notes);
    END
    ELSE IF (@Action = 1) -- UPDATE
    BEGIN
        UPDATE RoleAccount
        SET Actived = @Actived,
            Notes = @Notes
        WHERE AccountName = @AccountName AND RoleID = @RoleID;
    END
    ELSE IF (@Action = 2) -- DELETE
    BEGIN
        DELETE FROM RoleAccount WHERE AccountName = @AccountName AND RoleID = @RoleID;
    END
END;
GO

IF EXISTS (SELECT * FROM sys.objects WHERE type = 'P' AND name = 'RoleAccount_GetByAccountName')
    DROP PROCEDURE RoleAccount_GetByAccountName;
GO

CREATE PROCEDURE RoleAccount_GetByAccountName
    @AccountName NVARCHAR(100)
AS
BEGIN
    SET NOCOUNT ON;

    SELECT 
        ra.AccountName,
        ra.RoleID,
        r.RoleName,
        ra.Actived,
        ra.Notes
    FROM RoleAccount ra
    INNER JOIN Role r ON ra.RoleID = r.ID
    WHERE ra.AccountName = @AccountName;
END;
GO

/*Xoa account*/
ALTER TABLE RoleAccount
DROP CONSTRAINT FK__RoleAccou__Accou__4D94879B;

ALTER TABLE RoleAccount
ADD CONSTRAINT FK__RoleAccou__Accou__4D94879B
FOREIGN KEY (AccountName) REFERENCES Account(AccountName)
ON DELETE CASCADE;
/*Xoa Role*/
ALTER PROCEDURE Role_InsertUpdateDelete
    @ID INT,
    @RoleName NVARCHAR(100),
    @Path NVARCHAR(200),
    @Notes NVARCHAR(200),
    @Action INT
AS
BEGIN
    IF (@Action = 0) -- INSERT
    BEGIN
        INSERT INTO Role(RoleName, Path, Notes)
        VALUES (@RoleName, @Path, @Notes);
    END

    ELSE IF (@Action = 1) -- UPDATE
    BEGIN
        UPDATE Role
        SET RoleName = @RoleName,
            Path = @Path,
            Notes = @Notes
        WHERE ID = @ID;
    END

    ELSE IF (@Action = 2) -- DELETE
    BEGIN
        -- Xóa RoleAccount trước để tránh lỗi khóa ngoại
        DELETE FROM RoleAccount WHERE RoleID = @ID;

        -- Sau đó mới xóa Role
        DELETE FROM Role WHERE ID = @ID;
    END
END
GO



