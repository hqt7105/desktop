﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace DataAccess
{
    public class Table
    {
        public int ID { get; set; }
        public string TableCode { get; set; }
        public string Name { get; set; }
        public int Status { get; set; }
        public int Seats { get; set; }
        public int HallID { get; set; }
    }

    public class TableDA
    {
        public List<Table> GetAll()
        {
            SqlConnection conn = new SqlConnection(Ultilities.ConnectionString);
            conn.Open();

            SqlCommand cmd = conn.CreateCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = Ultilities.Table_GetAll;

            SqlDataReader reader = cmd.ExecuteReader();
            List<Table> list = new List<Table>();

            while (reader.Read())
            {
                Table table = new Table();
                table.ID = Convert.ToInt32(reader["ID"]);
                table.TableCode = reader["TableCode"].ToString();
                table.Name = reader["Name"].ToString();
                table.Status = Convert.ToInt32(reader["Status"]);
                table.Seats = reader["Seats"] == DBNull.Value ? 0 : Convert.ToInt32(reader["Seats"]);
                table.HallID = Convert.ToInt32(reader["HallID"]);

                list.Add(table);
            }

            conn.Close();
            return list;
        }

        public int Insert_Update_Delete(Table table, int action)
        {
            SqlConnection sqlConn = new SqlConnection(Ultilities.ConnectionString);
            sqlConn.Open();

            SqlCommand command = sqlConn.CreateCommand();
            command.CommandType = CommandType.StoredProcedure;
            command.CommandText = Ultilities.Table_InsertUpdateDelete;

            SqlParameter IDPara = new SqlParameter("@ID", SqlDbType.Int);
            IDPara.Direction = ParameterDirection.InputOutput;
            command.Parameters.Add(IDPara).Value = table.ID;

            command.Parameters.Add("@TableCode", SqlDbType.NVarChar, 200).Value = table.TableCode;
            command.Parameters.Add("@Name", SqlDbType.NVarChar, 1000).Value = table.Name;
            command.Parameters.Add("@Status", SqlDbType.Int).Value = table.Status;
            command.Parameters.Add("@Seats", SqlDbType.Int).Value = table.Seats;
            command.Parameters.Add("@HallID", SqlDbType.Int).Value = table.HallID;
            command.Parameters.Add("@Action", SqlDbType.Int).Value = action;

            int result = command.ExecuteNonQuery();

            if (result > 0)
            {
                return (int)command.Parameters["@ID"].Value;
            }

            return 0;
        }
    }
}
