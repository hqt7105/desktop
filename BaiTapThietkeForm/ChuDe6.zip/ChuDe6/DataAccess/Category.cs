﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess
{
    public class Category
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public int Type { get; set; }
    }

    public class CategoryDA
    {
        public List<Category> GetAll()
        {
            List<Category> list = new List<Category>();
            string query = "SELECT * FROM Category";

            using (SqlConnection conn = new SqlConnection(Ultilities.ConnectionString))
            {
                SqlCommand cmd = new SqlCommand(query, conn);
                conn.Open();
                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    Category category = new Category
                    {
                        ID = reader.GetInt32(0),
                        Name = reader.GetString(1),
                        Type = reader.GetInt32(2)
                    };
                    list.Add(category);
                }

                reader.Close();
            }

            return list;
        }

        public int Insert_Update_Delete(Category category, int action)
        {
            using (SqlConnection conn = new SqlConnection(Ultilities.ConnectionString))
            {
                SqlCommand cmd = new SqlCommand("Category_InsertUpdateDelete", conn);
                cmd.CommandType = CommandType.StoredProcedure;

                // Biến output @ID
                SqlParameter parID = new SqlParameter("@ID", SqlDbType.Int)
                {
                    Direction = ParameterDirection.InputOutput,
                    Value = category.ID
                };
                cmd.Parameters.Add(parID);

                cmd.Parameters.AddWithValue("@Name", category.Name);
                cmd.Parameters.AddWithValue("@Type", category.Type);
                cmd.Parameters.AddWithValue("@Action", action);

                conn.Open();
                int result = cmd.ExecuteNonQuery();

                // Nếu là thêm (Action = 0), cập nhật lại ID mới cho đối tượng
                if (action == 0)
                {
                    category.ID = Convert.ToInt32(parID.Value);
                }

                return result;
            }
        }
    }
}
