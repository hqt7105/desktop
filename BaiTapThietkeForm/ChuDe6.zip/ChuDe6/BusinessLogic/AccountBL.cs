﻿using DataAccess;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace BusinessLogic
{
    public class AccountBL
    {
        AccountDA da = new AccountDA();
        private string connectionString =
      ConfigurationManager.ConnectionStrings["KetNoiDB"].ConnectionString;
        public DataTable GetAll() => da.GetAll();
        public int Insert(Account acc) => da.InsertUpdateDelete(acc, 0);
        public int Update(Account acc) => da.InsertUpdateDelete(acc, 1);
        public int Delete(Account acc) => da.InsertUpdateDelete(acc, 2);
        public void Delete(string accountName)
        {
            string query = "DELETE FROM Account WHERE AccountName = @AccountName";

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@AccountName", accountName);
                    cmd.ExecuteNonQuery();
                }
            }
        }

    }
}
