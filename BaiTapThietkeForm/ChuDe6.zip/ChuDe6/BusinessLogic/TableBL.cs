﻿using System.Collections.Generic;
using DataAccess;

namespace BusinessLogic
{
    public class TableBL
    {
        TableDA tableDA = new TableDA();

        // Lấy toàn bộ dữ liệu
        public List<Table> GetAll()
        {
            return tableDA.GetAll();
        }

        // Thêm dữ liệu
        public int Insert(Table table)
        {
            return tableDA.Insert_Update_Delete(table, 0);
        }

        // Cập nhật dữ liệu
        public int Update(Table table)
        {
            return tableDA.Insert_Update_Delete(table, 1);
        }

        // Xóa dữ liệu
        public int Delete(Table table)
        {
            return tableDA.Insert_Update_Delete(table, 2);
        }
    }
}
