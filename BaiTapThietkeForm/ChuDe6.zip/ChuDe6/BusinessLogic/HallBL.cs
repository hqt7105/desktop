﻿using System.Collections.Generic;
using DataAccess;

namespace BusinessLogic
{
    public class HallBL
    {
        HallDA hallDA = new HallDA();

        public List<Hall> GetAll()
        {
            return hallDA.GetAll();
        }

        public int Insert(Hall hall)
        {
            return hallDA.Insert_Update_Delete(hall, 0);
        }

        public int Update(Hall hall)
        {
            return hallDA.Insert_Update_Delete(hall, 1);
        }

        public int Delete(Hall hall)
        {
            return hallDA.Insert_Update_Delete(hall, 2);
        }
    }
}
