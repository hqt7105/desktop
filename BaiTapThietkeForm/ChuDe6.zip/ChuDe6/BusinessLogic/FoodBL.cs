﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccess;

namespace BusinessLogic
{
    public class FoodBL
    {
        FoodDA foodDA = new FoodDA();

        public List<Food> GetAll()
        {
            return foodDA.GetAll();
        }

        public Food GetByID(int id)
        {
            List<Food> foods = GetAll();

            foreach (Food food in foods)
            {
                if (food.ID == id)
                {
                    return food;
                }
            }
            return null;
        }

        //Phương thức tìm kiếm theo khoa

        public List<Food> Find(string key)
        {
            List<Food> list = GetAll(); // Lay hết
            List<Food> result = new List<Food>();
            // Duyệt theo danh sach
            foreach (var item in list)
            {
                // Nếu từng trường chứa từ khoa
                if (item.ID.ToString().Contains(key)
                || item.Name.Contains(key)
                || item.Unit.Contains(key)
                || item.Price.ToString().Contains(key)
                || item.Notes.Contains(key)) ;
                result.Add(item); // Thì them vao danh sach ket quả
            }
            return result;
        }
        //Phuơng thức them du lieu
        public int Insert(Food food)
        {
            return foodDA.Insert_Update_Delete(food, 0);
        }
        //Phuơng thức cap nhat dữ liệu
        public int Update(Food food)
        {
            return foodDA.Insert_Update_Delete(food, 1);
        }
        //Phương thức xoa du lieu với ID cho trước
        public int Delete(Food food)
        {
            return foodDA.Insert_Update_Delete(food, 2);
        }

    }
}

