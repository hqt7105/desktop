﻿using System.Collections.Generic;
using DataAccess;

namespace BusinessLogic
{
    public class RestaurantBL
    {
        RestaurantDA restaurantDA = new RestaurantDA();

        public List<Restaurant> GetAll()
        {
            return restaurantDA.GetAll();
        }

        public int Insert(Restaurant restaurant)
        {
            return restaurantDA.Insert_Update_Delete(restaurant, 0);
        }

        public int Update(Restaurant restaurant)
        {
            return restaurantDA.Insert_Update_Delete(restaurant, 1);
        }

        public int Delete(Restaurant restaurant)
        {
            return restaurantDA.Insert_Update_Delete(restaurant, 2);
        }
    }
}
