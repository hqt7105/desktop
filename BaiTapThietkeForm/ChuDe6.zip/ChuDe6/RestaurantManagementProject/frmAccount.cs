﻿using System;
using System.Data;
using System.Windows.Forms;
using BusinessLogic;
using DataAccess;

namespace RestaurantManagementProject
{
    public partial class frmAccount : Form
    {
        private AccountBL bl = new AccountBL();
        private bool isNew = false;

        public frmAccount()
        {
            InitializeComponent();
        }

        private void dgvAccount_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && dgvAccount.CurrentRow != null)
            {
                string accName = dgvAccount.CurrentRow.Cells["AccountName"].Value.ToString();

                frmRoleAccount frm = new frmRoleAccount();
                frm.LoadForAccount(accName);
                frm.ShowDialog();
            }
        }


        private void frmAccount_Load(object sender, EventArgs e)
        {
            LoadData();
        }

        private void LoadData()
        {
            dgvAccount.DataSource = bl.GetAll();
        }

        private void ClearForm()
        {
            txtAccountName.Clear();
            txtPassword.Clear();
            txtFullName.Clear();
            txtEmail.Clear();
            txtPhone.Clear();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            // Tạo đối tượng tài khoản mới từ dữ liệu nhập
            Account acc = new Account()
            {
                AccountName = txtAccountName.Text,
                Password = txtPassword.Text,
                FullName = txtFullName.Text,
                Email = txtEmail.Text,
                Phone = txtPhone.Text
                
            };
                bl.Insert(acc);
            LoadData();
            ClearForm();
   
        }


        private void btnSave_Click(object sender, EventArgs e)
        {
            Account acc = new Account()
            {
                AccountName = txtAccountName.Text,
                Password = txtPassword.Text,
                FullName = txtFullName.Text,
                Email = txtEmail.Text,
                Phone = txtPhone.Text
            };
                bl.Update(acc);
            LoadData();
            ClearForm();
          
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (dgvAccount.CurrentRow == null)
                return;

            // Lấy tên tài khoản từ dòng đang chọn
            string accName = dgvAccount.CurrentRow.Cells["AccountName"].Value.ToString();

            if (MessageBox.Show("Bạn có chắc muốn xóa tài khoản này không?",
                "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                // Gọi hàm Delete trong lớp Business Layer
                bl.Delete(accName);

                // Load lại dữ liệu sau khi xóa
                LoadData();
                ClearForm();
                MessageBox.Show("Đã xóa tài khoản thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }


        private void btnRefresh_Click(object sender, EventArgs e)
        {
            LoadData();
            ClearForm();
            isNew = false;
        }

        private void dgvAccount_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && dgvAccount.CurrentRow != null)
            {
                txtAccountName.Text = dgvAccount.CurrentRow.Cells["AccountName"].Value.ToString();
                txtPassword.Text = dgvAccount.CurrentRow.Cells["Password"].Value.ToString();
                txtFullName.Text = dgvAccount.CurrentRow.Cells["FullName"].Value.ToString();
                txtEmail.Text = dgvAccount.CurrentRow.Cells["Email"].Value.ToString();
                txtPhone.Text = dgvAccount.CurrentRow.Cells["Phone"].Value.ToString();
                isNew = false;
            }
        }
    }
}
