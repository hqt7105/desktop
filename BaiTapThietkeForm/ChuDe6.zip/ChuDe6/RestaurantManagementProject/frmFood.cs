﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DataAccess;
using BusinessLogic;

namespace RestaurantManagementProject
{
    public partial class frmFood : Form
    {
        public frmFood()
        {
            InitializeComponent();
        }

        List<Category> listCategory = new List<Category>();
        List<Food> listFood = new List<Food>();
        Food foodCurrent = new Food();

        private void cmdExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void cmdClear_Click(object sender, EventArgs e)
        {
            txtName.Clear();
            txtPrice.Text = "0";
            txtUnit.Clear();
            txtNotes.Clear();

            if (cbbCategory.Items.Count > 0)
            {
                cbbCategory.SelectedIndex = 0;
            }
        }

        private void frmFood_Load(object sender, EventArgs e)
        {
            LoadCategory();
            LoadFoodDataToListView();
        }

        private void LoadCategory()
        {
            CategoryBL categoryBL = new CategoryBL();
            listCategory = categoryBL.GetAll();
            cbbCategory.DataSource = listCategory;
            cbbCategory.DisplayMember = "Name";
            cbbCategory.ValueMember = "ID";
        }

        public void LoadFoodDataToListView()
        {
            FoodBL foodBL = new FoodBL();
            listFood = foodBL.GetAll();
            int count = 1;
            lsvFood.Items.Clear();

            foreach (Food food in listFood)
            {
                ListViewItem item = new ListViewItem(food.ID.ToString());
                item.SubItems.Add(food.Name);
                item.SubItems.Add(food.Unit);
                item.SubItems.Add(food.Price.ToString());
                string foodName = listCategory.Find(x => x.ID == food.FoodCategoryID).Name;
                item.SubItems.Add(foodName);
                item.SubItems.Add(food.Notes);
                lsvFood.Items.Add(item);
                count++;
            }
        }

        private void lsvFood_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < lsvFood.Items.Count; i++)
            {
                if (lsvFood.Items[i].Selected)
                {
                    foodCurrent = listFood[i];
                    txtName.Text = foodCurrent.Name;
                    txtUnit.Text = foodCurrent.Unit;
                    txtPrice.Text = foodCurrent.Price.ToString();
                    txtNotes.Text = foodCurrent.Notes;
                    cbbCategory.SelectedIndex = listCategory.FindIndex(x => x.ID == foodCurrent.FoodCategoryID);
                }
            }
        }

        public int InsertFood()
        {
            Food food = new Food();
            food.ID = 0;
            if (txtName.Text.Trim() == "")
            {
                MessageBox.Show("Please enter food name");
            }
            else if (txtUnit.Text.Trim() == "")
            {
                MessageBox.Show("Please enter unit");
            }
            else if (txtPrice.Text.Trim() == "")
            {
                MessageBox.Show("Please enter price");
            }
            else
            {
                food.Name = txtName.Text.Trim();
                food.Unit = txtUnit.Text.Trim();
                food.Notes = txtNotes.Text.Trim();

                int price = 0;
                try
                {
                    price = int.Parse(txtPrice.Text.Trim());
                }
                catch (Exception)
                {
                    MessageBox.Show("Price must be a number");
                    price = 0;
                }
                food.Price = price;
                food.FoodCategoryID = int.Parse(cbbCategory.SelectedValue.ToString());
                FoodBL foodBL = new FoodBL();
                return foodBL.Insert(food);
            }
            return -1;
        }

        private void cmdAdd_Click(object sender, EventArgs e)
        {
                int result = InsertFood();
            if (result > 0)
            {
                MessageBox.Show("Food added successfully");
                LoadFoodDataToListView();
                cmdClear.PerformClick();
            }
            else if (result == 0)
            {
                MessageBox.Show("Failed to add food");
            }
        }

        private void cmdDelete_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure to delete this food?", "Confirm",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                FoodBL foodBL = new FoodBL();
                if (foodBL.Delete(foodCurrent) > 0)
                {
                    MessageBox.Show("Food deleted successfully");
                    LoadFoodDataToListView();
                    cmdClear.PerformClick();
                }
                else
                {
                    MessageBox.Show("Failed to delete food");
                }
            }
        }

        private void cmdUpdate_Click(object sender, EventArgs e)
        {
            int result = UpdateFood();
            if (result > 0)
            {
                MessageBox.Show("Food updated successfully");
                LoadFoodDataToListView();
                cmdClear.PerformClick();
            }
            else if (result == 0)
            {
                MessageBox.Show("Failed to update food");
            }
        }

        public int UpdateFood()
        {
            Food food = new Food();
            food.ID = foodCurrent.ID;
            if (txtName.Text.Trim() == "")
            {
                MessageBox.Show("Please enter food name");
            }
            else if (txtUnit.Text.Trim() == "")
            {
                MessageBox.Show("Please enter unit");
            }
            else if (txtPrice.Text.Trim() == "")
            {
                MessageBox.Show("Please enter price");
            }
            else
            {
                food.Name = txtName.Text.Trim();
                food.Unit = txtUnit.Text.Trim();
                food.Notes = txtNotes.Text.Trim();
                int price = 0;
                try
                {
                    price = int.Parse(txtPrice.Text.Trim());
                }
                catch (Exception)
                {
                    MessageBox.Show("Price must be a number");
                    price = 0;
                }
                food.Price = price;
                food.FoodCategoryID = int.Parse(cbbCategory.SelectedValue.ToString());
                FoodBL foodBL = new FoodBL();
                return foodBL.Update(food);
            }
            return -1;
        }
    }
}
