﻿using DataAccess;
using RestaurantManagement;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RestaurantManagementProject
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void accountToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmAccount frmAccount = new frmAccount();
            frmAccount.Show();
        }

        private void roleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmRole frmRole = new frmRole();
            frmRole.Show();
        }

        private void categoryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmCategory frmCategory = new frmCategory();
            frmCategory.Show();
        }

        private void foodToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmFood frmFood = new frmFood();
            frmFood.Show();
        }

        private void invoiceToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmInvoice frmInvoice = new frmInvoice();
            frmInvoice.Show();
        }

        private void restaurantToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmRestaurant frmRestaurant = new frmRestaurant();
            frmRestaurant.Show();
        }

        private void tabelToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
    }
}
